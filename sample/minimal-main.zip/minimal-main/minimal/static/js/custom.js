
//THIS FUNCTION IS CALLED BY THE FOOTER LINK: IT SHOULD OPEN THE 
//COOKIE ALERT MODAL.
function open_cookie_alert(){
    var myModal = new bootstrap.Modal(document.getElementById('cookieModal'));
	myModal.show();
}

