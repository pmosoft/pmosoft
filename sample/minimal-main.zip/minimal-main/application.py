from minimal import create_app

application = create_app()

